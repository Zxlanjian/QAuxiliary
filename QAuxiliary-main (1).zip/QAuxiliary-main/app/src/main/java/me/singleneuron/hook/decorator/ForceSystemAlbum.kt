/*
 * QNotified - An Xposed module for QQ/TIM
 * Copyright (C) 2019-2022 dmca@ioctl.cc
 * https://github.com/ferredoxin/QNotified
 *
 * This software is non-free but opensource software: you can redistribute it
 * and/or modify it under the terms of the GNU Affero General Public License
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version and our eula as published
 * by ferredoxin.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * and eula along with this software.  If not, see
 * <https://www.gnu.org/licenses/>
 * <https://github.com/ferredoxin/QNotified/blob/master/LICENSE.md>.
 */
package me.singleneuron.hook.decorator

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.view.View
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import io.github.qauxv.base.IUiItemAgent
import io.github.qauxv.base.annotation.FunctionHookEntry
import io.github.qauxv.base.annotation.UiItemAgentEntry
import io.github.qauxv.config.ConfigManager
import io.github.qauxv.dsl.FunctionEntryRouter
import io.github.qauxv.router.decorator.BaseConfigFunctionDecorator
import io.github.qauxv.router.decorator.IStartActivityHookDecorator
import io.github.qauxv.router.dispacher.StartActivityHook
import io.github.qauxv.ui.CommonContextWrapper
import io.github.qauxv.util.Log
import io.github.qauxv.util.xpcompat.XC_MethodHook
import kotlinx.coroutines.flow.MutableStateFlow
import me.singleneuron.activity.ChooseAgentActivity

@UiItemAgentEntry
@FunctionHookEntry
object ForceSystemAlbum : BaseConfigFunctionDecorator(), IStartActivityHookDecorator {
    const val ALBUM_TYPE = "me.singleneuron.hook.decorator.ForceSystemAlbum.albumType"
    const val ALBUM_TYPE_DEFAULT = 2 // QQ 相册 (禁用)
    val albumTypes = arrayOf("系统相册", "系统文档", "QQ 相册 (禁用)", "每次询问")

    override val name = "可选使用系统相册"
    override val description = "支持8.3.6及更高"
    override val uiItemLocation = FunctionEntryRouter.Locations.Simplify.UI_CHAT_MSG
    override val valueState = MutableStateFlow(albumTypes[ConfigManager.getDefaultConfig().getInt(ALBUM_TYPE, ALBUM_TYPE_DEFAULT)])
    override val dispatcher = StartActivityHook

    override val onUiItemClickListener: (IUiItemAgent, Activity, View) -> Unit
        get() = { _, activity, _ ->
            AlertDialog.Builder(activity)
                .setTitle("选择相册类型")
                .setSingleChoiceItems(albumTypes, ConfigManager.getDefaultConfig().getInt(ALBUM_TYPE, ALBUM_TYPE_DEFAULT)) { dialog, which ->
                    ConfigManager.getDefaultConfig().putInt(ALBUM_TYPE, which)
                    valueState.value = albumTypes[which]
                    isEnabled = which != ALBUM_TYPE_DEFAULT
                    dialog.dismiss()
                }.setNegativeButton(android.R.string.cancel, null)
                .show()
        }

    override fun onStartActivityIntent(intent: Intent, param: XC_MethodHook.MethodHookParam): Boolean {
        val isWinkHomeActivity = intent.component?.className?.contains("WinkHomeActivity") == true
        val isNewPhotoListActivity = intent.component?.className?.contains("NewPhotoListActivity") == true
        if ((isWinkHomeActivity || (isNewPhotoListActivity && intent.getIntExtra("uintype", -1) != -1)) &&
            (!intent.getBooleanExtra("PhotoConst.IS_CALL_IN_PLUGIN", false)) &&
            (!intent.getBooleanExtra("is_decorated", false))
        ) {
            // must use Activity context as base context to show dialog window
            val uin = intent.getStringExtra("uin")
            if (uin.toString().length > 10) {
                // Filter out calls in the guild
                return true
            }
            val context = param.thisObject as Context
            Log.d("context: ${context.javaClass.name}")
            val materialContext = CommonContextWrapper.createMaterialDesignContext(context)
            val runnableArray = arrayOf(
                "系统相册" to {
                    MaterialAlertDialogBuilder(materialContext)
                        .setTitle("系统相册")
                        .setItems(arrayOf("图片", "视频"), { _, i ->
                            val intent = Intent(context, ChooseAgentActivity::class.java).apply ChooseAgentActivity@{
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                putExtras(intent)
                                putExtra("chooser_intent", Intent(Intent.ACTION_PICK).apply {
                                    type = when (i) {
                                        0 -> "image/*"
                                        1 -> "video/*"
                                        else -> "*/*"
                                    }
                                    if (type == "image/*") {
                                        this@ChooseAgentActivity.putExtra("forward_type", 1)
                                    }
                                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                                })
                            }
                            context.startActivity(intent)
                        })
                        .show()
                },
                "系统文档" to {
                    MaterialAlertDialogBuilder(materialContext)
                        .setTitle("系统文档")
                        .setItems(arrayOf("图片", "视频"), { _, i ->
                            val intent = Intent(context, ChooseAgentActivity::class.java).apply ChooseAgentActivity@{
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                putExtras(intent)
                                putExtra("chooser_intent", Intent(Intent.ACTION_GET_CONTENT).apply {
                                    type = when (i) {
                                        0 -> "image/*"
                                        1 -> "video/*"
                                        else -> "*/*"
                                    }
                                    if (type == "image/*") {
                                        this@ChooseAgentActivity.putExtra("forward_type", 1)
                                    }
                                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                                })
                            }
                            context.startActivity(intent)
                        })
                        .show()
                },
                "QQ 相册" to {
                    intent.putExtra("is_decorated", true)
                    context.startActivity(intent)
                }
            )
            val selectedType = runnableArray.getOrNull(ConfigManager.getDefaultConfig().getInt(ALBUM_TYPE, ALBUM_TYPE_DEFAULT))
            if (selectedType != null) {
                selectedType.second.invoke()
            } else {
                MaterialAlertDialogBuilder(materialContext)
                    .setTitle("选择相册")
                    .setItems(runnableArray.map { it.first }.toTypedArray()) { _: DialogInterface, i: Int ->
                        // recursion here
                        runnableArray[i].second.invoke()
                    }
                    .create()
                    .show()
            }
            param.result = null
            return true
        }
        return false
    }
}
