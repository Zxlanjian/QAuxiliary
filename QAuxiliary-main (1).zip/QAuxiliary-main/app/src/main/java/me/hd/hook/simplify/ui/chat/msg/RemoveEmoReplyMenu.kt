/*
 * QAuxiliary - An Xposed module for QQ/TIM
 * Copyright (C) 2019-2026 QAuxiliary developers
 * https://github.com/cinit/QAuxiliary
 *
 * This software is an opensource software: you can redistribute it
 * and/or modify it under the terms of the General Public License
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version as published
 * by QAuxiliary contributors.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the General Public License for more details.
 *
 * You should have received a copy of the General Public License
 * along with this software.
 * If not, see
 * <https://github.com/cinit/QAuxiliary/blob/master/LICENSE.md>.
 */

package me.hd.hook.simplify.ui.chat.msg

import android.content.Context
import io.github.qauxv.base.annotation.FunctionHookEntry
import io.github.qauxv.base.annotation.UiItemAgentEntry
import io.github.qauxv.dsl.FunctionEntryRouter
import io.github.qauxv.hook.CommonSwitchFunctionHook
import io.github.qauxv.util.QQVersion
import io.github.qauxv.util.dexkit.Hd_RemoveEmoReplyMenu_Method
import io.github.qauxv.util.requireMinQQVersion
import me.hd.util.hookBeforeIfEnabled
import me.hd.util.name
import me.hd.util.parameters
import me.hd.util.returnType
import me.hd.util.singleMethod
import me.hd.util.toHostClass
import me.hd.util.toHostMethod

@FunctionHookEntry
@UiItemAgentEntry
object RemoveEmoReplyMenu : CommonSwitchFunctionHook(
    targets = arrayOf(Hd_RemoveEmoReplyMenu_Method)
) {
    override val name = "移除消息表态"
    override val description = "移除消息菜单中的表情回应"
    override val uiItemLocation = FunctionEntryRouter.Locations.Simplify.UI_CHAT_MSG
    override val isAvailable = requireMinQQVersion(QQVersion.QQ_9_0_8)

    override fun initOnce(): Boolean {
        Hd_RemoveEmoReplyMenu_Method.toHostMethod()
            .hookBeforeIfEnabled(this) { param ->
                param.result = null
            }
        if (requireMinQQVersion(QQVersion.QQ_9_1_75)) {
            "com.tencent.qqnt.aio.api.impl.AIOEmoReplyMenuApiImpl".toHostClass()
                .singleMethod {
                    returnType(Boolean::class.java) &&
                        name("hasEmoReplyMenu") &&
                        parameters(Context::class.java, "com.tencent.mobileqq.aio.msg.AIOMsgItem".toHostClass())
                }.hookBeforeIfEnabled(this) { param ->
                    param.result = false
                }
        }
        return true
    }
}
