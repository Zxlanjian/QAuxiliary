/*
 * QAuxiliary - An Xposed module for QQ/TIM
 * Copyright (C) 2019-2026 QAuxiliary developers
 * https://github.com/cinit/QAuxiliary
 *
 * This software is an opensource software: you can redistribute it
 * and/or modify it under the terms of the General Public License
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version as published
 * by QAuxiliary contributors.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the General Public License for more details.
 *
 * You should have received a copy of the General Public License
 * along with this software.
 * If not, see
 * <https://github.com/cinit/QAuxiliary/blob/master/LICENSE.md>.
 */

package me.hd.hook.simplify.main.ui.operation.log

import io.github.qauxv.base.annotation.FunctionHookEntry
import io.github.qauxv.base.annotation.UiItemAgentEntry
import io.github.qauxv.dsl.FunctionEntryRouter
import io.github.qauxv.hook.CommonSwitchFunctionHook
import io.github.qauxv.util.QQVersion
import io.github.qauxv.util.requireMinQQVersion
import me.hd.util.hookBeforeIfEnabled
import me.hd.util.name
import me.hd.util.returnType
import me.hd.util.singleMethod
import me.hd.util.toHostClass

@FunctionHookEntry
@UiItemAgentEntry
object ShowServiceRemove : CommonSwitchFunctionHook() {
    override val name = "显示业务右上角移除选项"
    override val description = "动态-更多, 业务页可移除游戏中心等"
    override val extraSearchKeywords = arrayOf("游戏中心")
    override val uiItemLocation = FunctionEntryRouter.Locations.Simplify.MAIN_UI_OPERATION_LOG
    // 目标 LebaPluginInfo.getAllowModify()Z 在 8.8.50 已存在（<9.0.35 走 getAllowModify 分支），放宽版本门
    override val isAvailable = requireMinQQVersion(QQVersion.QQ_8_8_50)

    override fun initOnce(): Boolean {
        "com.tencent.mobileqq.leba.entity.LebaPluginInfo".toHostClass()
            .singleMethod {
                returnType(Boolean::class.java) &&
                    name(if (requireMinQQVersion(QQVersion.QQ_9_0_35)) "isAllowUserChange" else "getAllowModify")
            }.hookBeforeIfEnabled(this) { param ->
                param.result = true
            }
        return true
    }
}
