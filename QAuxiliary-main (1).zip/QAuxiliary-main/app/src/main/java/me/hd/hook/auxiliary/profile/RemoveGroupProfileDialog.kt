/*
 * QAuxiliary - An Xposed module for QQ/TIM
 * Copyright (C) 2019-2026 QAuxiliary developers
 * https://github.com/cinit/QAuxiliary
 *
 * This software is an opensource software: you can redistribute it
 * and/or modify it under the terms of the General Public License
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version as published
 * by QAuxiliary contributors.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the General Public License for more details.
 *
 * You should have received a copy of the General Public License
 * along with this software.
 * If not, see
 * <https://github.com/cinit/QAuxiliary/blob/master/LICENSE.md>.
 */

package me.hd.hook.auxiliary.profile

import android.os.Bundle
import io.github.qauxv.base.annotation.FunctionHookEntry
import io.github.qauxv.base.annotation.UiItemAgentEntry
import io.github.qauxv.dsl.FunctionEntryRouter
import io.github.qauxv.hook.CommonSwitchFunctionHook
import io.github.qauxv.util.QQVersion
import io.github.qauxv.util.requireMinQQVersion
import me.hd.util.hookBeforeIfEnabled
import me.hd.util.name
import me.hd.util.parameters
import me.hd.util.singleMethod
import me.hd.util.toHostClass
import xyz.nextalone.util.get
import xyz.nextalone.util.set

@FunctionHookEntry
@UiItemAgentEntry
object RemoveGroupProfileDialog : CommonSwitchFunctionHook() {
    override val name = "移除群成员资料卡异常弹窗"
    override val description = "忽略账号异常状态, 使其可以正常查看"
    override val uiItemLocation = FunctionEntryRouter.Locations.Auxiliary.PROFILE_CATEGORY
    override val isAvailable = requireMinQQVersion(QQVersion.QQ_8_9_88)

    override fun initOnce(): Boolean {
        "com.tencent.mobileqq.profilecard.processor.ProfileSecureProcessor".toHostClass()
            .singleMethod {
                name("processProfileCard") &&
                    if (requireMinQQVersion(QQVersion.QQ_9_0_0)) {
                        parameters(Bundle::class.java, "SummaryCard.RespHead".toHostClass(), "SummaryCard.RespSummaryCard".toHostClass())
                    } else {
                        parameters("SummaryCard.RespHead".toHostClass(), "SummaryCard.RespSummaryCard".toHostClass())
                    }
            }.hookBeforeIfEnabled(this) { param ->
                val respHead = if (requireMinQQVersion(QQVersion.QQ_9_0_0)) param.args[1] else param.args[0]
                val iResult = respHead.get("iResult")
                if (iResult == 201 || iResult == 202) {
                    respHead.set("iResult", 0)
                }
            }
        return true
    }
}
