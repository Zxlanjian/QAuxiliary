/*
 * QAuxiliary - An Xposed module for QQ/TIM
 * Copyright (C) 2019-2022 qwq233@qwq2333.top
 * https://github.com/cinit/QAuxiliary
 *
 * This software is non-free but opensource software: you can redistribute it
 * and/or modify it under the terms of the GNU Affero General Public License
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version and our eula as published
 * by QAuxiliary contributors.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * and eula along with this software.  If not, see
 * <https://www.gnu.org/licenses/>
 * <https://github.com/cinit/QAuxiliary/blob/master/LICENSE.md>.
 */

package me.ketal.hook

import android.os.Bundle
import com.github.kyuubiran.ezxhelper.utils.findMethod
import io.github.qauxv.base.annotation.FunctionHookEntry
import io.github.qauxv.base.annotation.UiItemAgentEntry
import io.github.qauxv.dsl.FunctionEntryRouter
import io.github.qauxv.hook.CommonSwitchFunctionHook
import io.github.qauxv.util.Initiator
import io.github.qauxv.util.QQVersion
import io.github.qauxv.util.TIMVersion
import io.github.qauxv.util.requireMinQQVersion
import io.github.qauxv.util.requireMinTimVersion
import xyz.nextalone.util.hookBefore
import xyz.nextalone.util.throwOrTrue

@FunctionHookEntry
@UiItemAgentEntry
object RemoveQRLoginAuth : CommonSwitchFunctionHook() {

    override val name = "去除相册扫码登录检验"
    override val uiItemLocation = FunctionEntryRouter.Locations.Auxiliary.MISC_CATEGORY
    override val isAvailable = requireMinQQVersion(QQVersion.QQ_8_5_0) || requireMinTimVersion(TIMVersion.TIM_4_0_95_BETA)

    override fun initOnce() = throwOrTrue {
        val managerClass = when {
            requireMinQQVersion(QQVersion.QQ_8_9_70) || requireMinTimVersion(TIMVersion.TIM_4_0_95_BETA) -> "com/tencent/open/agent/QrAgentLoginManager"
            requireMinQQVersion(QQVersion.QQ_8_9_0) -> "com/tencent/open/agent/QrAgentLoginManager\$a"
            else -> "com/tencent/open/agent/QrAgentLoginManager\$2"
        }
        Initiator.loadClass(managerClass).findMethod {
            returnType == Void.TYPE && parameterTypes.isNotEmpty() &&
                if (requireMinQQVersion(QQVersion.QQ_9_2_30)) {
                    parameterTypes[1] == Boolean::class.java && parameterTypes[2] == String::class.java && parameterTypes[3] == Bundle::class.java
                } else {
                    parameterTypes[0] == Boolean::class.java
                }
        }.hookBefore(this) {
            if (it.args[0] is Boolean) {
                it.args[0] = false
            } else if (it.args.size > 1 && it.args[1] is Boolean) {
                it.args[1] = false
            }
        }
    }
}
